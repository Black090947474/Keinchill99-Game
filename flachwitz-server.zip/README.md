# Flachwitz-Jury Server (für keinchill99)

Ein Server, der das Spiel UND die Online-Räume ausliefert. Jeder mit dem Link kann spielen, ohne Account.

## Starten auf dem eigenen PC (zum Testen)
    node server.js
Dann im Browser: http://localhost:3000

## Online stellen (kostenlos, z. B. Render.com)
1. Lege ein GitHub-Konto an und lade diese 4 Dateien in ein neues Repository hoch.
2. Auf render.com: New → Web Service → dein Repository auswählen.
3. Build Command leer lassen, Start Command: `node server.js`
4. Unter Environment diese Variablen setzen:
   - `HOST_CODE` = dein geheimer Host-Code (Pflicht!)
   - `ANTHROPIC_API_KEY` = optional, für echte KI-Bewertung (sonst bewertet die eingebaute Jury)
5. Deploy drücken. Render gibt dir einen Link wie https://flachwitz.onrender.com. Den teilst du.

## So funktioniert es
- Nur wer den Host-Code kennt, kann einen Raum erstellen (der Server prüft das).
- Spieler treten mit dem 4-stelligen Raumcode bei und werden 1 gegen 1 gepaart.
- Findet sich nach 60 Sekunden kein Gegner, spielt man gegen die KI.
- Kostenlose Render-Server schlafen nach Inaktivität ein und brauchen ca. 1 Minute zum Aufwachen.
- Räume liegen nur im Arbeitsspeicher und sind nach einem Neustart weg.
